module Fullstack2 {
	requires java.sql;
}